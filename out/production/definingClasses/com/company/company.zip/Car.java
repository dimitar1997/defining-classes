package com.company;

import java.util.ArrayList;
import java.util.List;

public class Car {
    private String make;

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getHorsePower() {
        return horsePower;
    }

    public void setHorsePower(int horsePower) {
        this.horsePower = horsePower;
    }

    private String model;
    private int horsePower;

    public String getInfo(String name, String model, int power){
        String carInfo = (String.format("The car is: %s %s - %d HP.",
                name, model, power));
        return carInfo;
    }

}
